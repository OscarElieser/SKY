# NeuralT Personal — MLP + GRU Engine Sensor

**Prototipo independiente, no reproducción de software comercial NeuralT v4.0.**

Este proyecto permite entrenar una red híbrida MLP + GRU con series temporales de cinco sensores, visualizar valores y estimar la siguiente lectura. Usa datos sintéticos por defecto; un hardware real solo funcionará después de integrar su captura y calibrar el modelo.

## Instalación

Requiere Python 3.10+ y una computadora Windows, macOS o Linux.

```bash
cd neuralT_personal
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS o Linux: source .venv/bin/activate
pip install -r requirements.txt
python generar_demo.py
python entrenar.py --csv data/demo_sensores.csv
streamlit run app.py
```

Si la carpeta ya incluye `data/demo_sensores.csv` y `modelos/neuralT.pt`, no necesitas regenerar ni entrenar para ver la demostración. Al entrenar sobre un CSV personal reemplazarás el modelo local.

## Formato CSV

Una fila por lectura, en **orden cronológico**, con intervalos consistentes. Se aceptan columnas adicionales. Las cinco columnas obligatorias son:

`temperatura_c,vibracion_mm_s,rpm,corriente_a,presion_bar`

Ejemplo:

```csv
fecha_hora,temperatura_c,vibracion_mm_s,rpm,corriente_a,presion_bar
2026-10-18 08:00,69.4,2.0,1950,7.6,3.2
2026-10-18 08:01,69.8,2.1,1980,7.8,3.2
```

Para entrenar se requieren **100 o más filas**. Los primeros 80 % se usan para aprendizaje y el 20 % final para validación (sin mezclar el orden temporal). La normalización se calcula únicamente en los datos de entrenamiento. El modelo utiliza las últimas 24 lecturas para pronosticar la siguiente.

## Arquitectura

- **Rama MLP:** procesa la lectura más reciente.
- **Rama GRU:** procesa la ventana temporal de las últimas 24 lecturas.
- **Cabeza densa:** fusiona ambas ramas y pronostica los cinco valores siguientes.
- **Anomalías:** desviaciones respecto del pronóstico con umbrales calculados a partir de errores de validación del mismo dataset.

## Limitaciones y seguridad

- El modelo precargado, si lo hay, está entrenado **solo con datos sintéticos**; no indica condiciones reales de un motor.
- No clasifica fallas mecánicas ni estima seguridad operativa: solo genera predicciones de un paso y detecta desviaciones estadísticas.
- Las métricas de validación no son una estimación independiente de desempeño en producción. Hace falta un conjunto de prueba externo y contrastar contra reglas de seguridad reales.
- No conectes el software a actuadores o mecanismos críticos. No sustituye sistemas certificados ni inspecciones técnicas.
- Las cargas de CSV se almacenan solo en `local_data/sensores_usuario.csv`; mantenlas en un equipo protegido. No compartas el archivo `modelos/neuralT.pt` si no quieres compartir los parámetros derivados de tus datos.
- No es una app Android; es una aplicación local accesible en el navegador de tu computadora.

## Archivos

`modelo.py`: red neuronal; `motor.py`: lectura y predicción; `entrenar.py`: entrenamiento; `generar_demo.py`: CSV simulado; `app.py`: panel Streamlit.

**Próximo paso:** cuando definas qué quieres medir o pronosticar, adaptar las columnas y entradas a tus datos reales.
