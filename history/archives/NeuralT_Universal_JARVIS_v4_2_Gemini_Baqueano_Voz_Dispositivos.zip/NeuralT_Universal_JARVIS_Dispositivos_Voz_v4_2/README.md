# 🧠 NeuralT Universal JARVIS v4.2 — Gemini, voz y dispositivos privados

Esta entrega **amplía el proyecto v4.1**, sin borrar las funciones de Gemini, BAQUEANO, finanzas, bolsa/Bitcoin, multimedia, investigación, seguridad defensiva, CRM ni el motor experimental MLP+GRU.

## Qué incorporamos ahora

- **JARVIS de voz pulsar-para-hablar:** desde el navegador grabás una instrucción en español; Gemini transcribe WAV, clasifica si es pregunta o acción sobre tu equipo y devuelve una respuesta. Voz de salida MP3 con gTTS opcional (requiere Internet, envía el texto a Google). El micrófono requiere permiso del navegador; en móvil remoto se recomienda HTTPS.
- **Modo manos libres opcional en PC:** proceso `jarvis_manos_libres.py` con Vosk, reconocimiento de palabra «Jarvis» y síntesis local pyttsx3 cuando está disponible. No escucha en secreto: sólo funciona mientras el proceso está encendido; Ctrl+C lo apaga. La transcripción inicial se hace local con Vosk; las preguntas de texto se envían a Gemini si ese proveedor está habilitado.
- **Agente para computadoras tuyas:** `agente_dispositivo.py`, compatible a nivel de código con Windows, Linux y macOS. Necesita que lo instales y lo ejecutes en **cada** computadora a controlar.
- **Emparejamiento verificado:** token aleatorio exclusivo por instalación y conexión HTTPS mediante Tailscale Serve o HTTP sólo en `localhost`. Los tokens introducidos en el panel se conservan **únicamente en la sesión**, no en el registro de dispositivos.
- **Acciones permitidas iniciales:** consultar estado del equipo, abrir sitios HTTPS y abrir calculadora, editor de texto, explorador de archivos o navegador. Las órdenes propuestas mediante voz o texto **requieren confirmación manual en el panel** antes de ejecutarse.
- **Cola de acciones por voz:** el modo manos libres puede preparar órdenes sin ejecutarlas; el panel permite revisarlas y aprobarlas.
- **Opcional:** contraseña propia `NEURALT_DASHBOARD_PASSWORD` para proteger el panel si lo compartís de forma privada por Tailscale.

## Inicio en tu computadora

1. Instalá **Python 3.11 o 3.12** y extraé el ZIP completo.
2. Copiá `.env.example` a `.env`, escribí `GEMINI_API_KEY=tu_clave` y, si vas a acceder desde otros dispositivos, agregá `NEURALT_DASHBOARD_PASSWORD=una-contraseña-larga-y-única` (mínimo 12 caracteres; mejor 20 o más).
3. Ejecutá `INICIAR_WINDOWS.bat` (Windows) o `bash iniciar_linux_mac.sh` (Linux/macOS). Los scripts crean el entorno virtual e instalan las dependencias cuando tenés acceso a Internet.
4. Abrí en tu PC `http://127.0.0.1:8501`, seleccioná **🎙️ JARVIS y dispositivos** y probá la función **Hablar con JARVIS**. También podés escribir preguntas.

Si instalás manualmente, ejecutá:

```bash
python -m venv .venv
# Activá .venv y luego:
python -m pip install -r requirements.txt
python -m streamlit run app.py --server.address 127.0.0.1
```

## Emparejar otro dispositivo PC/Mac/Linux

En cada equipo controlado, ejecutá uno de estos comandos (o el lanzador `INICIAR_AGENTE_WINDOWS.bat`):

```bash
python agente_dispositivo.py
```

El agente escuchará **sólo en `127.0.0.1:8765`** y mostrará un token privado en la terminal. Guardalo en un lugar seguro.

- **Si NeuralT y el agente están en la misma computadora:** dirección `http://127.0.0.1:8765` y token del agente.
- **Si estás en otro lugar:** instalá Tailscale en ambos equipos y conectalos a tu red privada (tailnet); en el PC que tiene el agente ejecutá `tailscale serve --https=8765 8765`. Copiá la dirección HTTPS que anuncie Tailscale, incluyendo `:8765`, y emparejá con el token desde NeuralT.
- **Si querés entrar al panel NeuralT desde Android o un segundo PC:** configurá la contraseña del panel, mantenelo escuchando sólo en localhost y ejecutá **en el equipo donde corre Streamlit** `tailscale serve --https=8501 8501`. Abrí la dirección HTTPS anunciada desde tu celular con Tailscale y habilitá el micrófono cuando lo pida.
- Es posible que Tailscale solicite activar certificados HTTPS y permisos en tu red privada. No uses **Tailscale Funnel** ni abras los puertos 8501/8765 a Internet público.

**Nota sobre los dos servicios:** se configuran en puertos HTTPS distintos (8765 para el agente; 8501 para el panel) para que puedan coexistir en un equipo sin reemplazarse.

### Órdenes de ejemplo

- “Jarvis, abrí BAQUEANO” → prepara abrir `https://baqueanonicaragua.com` en el equipo seleccionado.
- “Jarvis, abrí la calculadora” → prepara lanzar una aplicación aprobada.
- “Jarvis, consultá el estado de mi computadora” → prepara o realiza, desde el botón del panel, una consulta de estado.
- “Jarvis, diseñame una campaña para conseguir negocios” → pregunta a Gemini u Ollama.

Las propuestas muestran el equipo, la acción y los parámetros. Debés confirmar antes de ejecutarlas.

## Modo manos libres con palabra «Jarvis» (opcional)

Necesita un micrófono, modelo español Vosk descargado y dependencias de audio del sistema:

```bash
python -m pip install vosk sounddevice pyttsx3
# Descargá y extraé un modelo oficial español de https://alphacephei.com/vosk/models
python jarvis_manos_libres.py --model "ruta/a/tu/modelo-vosk-es"
```

Escucha en primer plano **sólo mientras el programa está en ejecución**. Cuando detecta «Jarvis» procesa la frase siguiente. Las instrucciones de control se escriben en la cola local y se **confirman en el panel**, no se ejecutan solas. En equipos donde pyttsx3 no puede sintetizar voz, la respuesta puede verse en la terminal.

## Seguridad, alcance y limitaciones

- Esto no equivale a control ilimitado de cualquier dispositivo: cada equipo debe ser tuyo o contar con permiso explícito, tener un sistema compatible, el agente instalado y conexión activa.
- La primera entrega controla **computadoras con agente**, no Android/iOS de forma nativa, cámaras, routers, TVs, electrodomésticos ni dispositivos apagados. Para más categorías se necesitan conectores específicos, APIs y permisos de cada fabricante.
- El LLM **no puede ejecutar comandos de shell arbitrarios**, instalar software o cambiar archivos libremente. El agente sólo responde a una lista explícita de acciones; mantiene un log local en `~/.neuralt/device_agent_audit.jsonl`.
- No hay claves reales incorporadas, activación remota silenciosa, acceso oculto a cámaras/micrófonos, toma de control de terceros ni movimientos automáticos de dinero.
- Gemini, Google TTS y las fuentes de Internet requieren conectividad y pueden tener costos y límites de uso. Vosk permite reconocer la voz localmente al instalar el modelo, pero no hace que Gemini funcione sin Internet.
- **BAQUEANO Control Center se mantiene como en v4.1**: monitoreo y lectura autorizada, propuestas de cambios por GitHub Pull Requests. No se publicó ni alteró la web ni se añadió acceso administrativo privado sin verificar su autenticación.
- **No es producción**: las 37 pruebas automatizadas (incluidas las 14 anteriores y 23 nuevas) se ejecutaron sobre lógica y un servidor HTTP local de prueba. No se verificaron micrófonos físicos, Gemini real, Tailscale real, Windows/macOS reales ni la representación visual del panel Streamlit.

Para probar:

```bash
python -m pytest -q
```

Documentación de las bases utilizadas: [Streamlit audio_input](https://docs.streamlit.io/develop/api-reference/widgets/st.audio_input), [Gemini audio](https://ai.google.dev/gemini-api/docs/generate-content/audio), [Tailscale Serve](https://tailscale.com/docs/reference/tailscale-cli/serve).

---

# Documentación heredada de NeuralT v4.1 (se mantiene para consulta)

# 🧠 NeuralT Universal Personal v4.1 — Gemini + BAQUEANO Control Center

Versión ampliada del prototipo NeuralT v4.0. Es una **aplicación web local para uso personal** que combina módulos prácticos con IA generativa (Google Gemini o Ollama). Se conserva el motor experimental **MLP + GRU** para series de sensores.

## Novedades v4.1 implementadas

1. **Gemini en el chat universal:** pregunta libre sobre educación, finanzas, investigación, IA, música, tecnología, marketing, programación, bolsa, Bitcoin, salud informativa, negocios y otras categorías. Conserva la biblioteca local de documentos y recuerdos.
2. **Selector Gemini / Ollama:** Gemini por API Key como motor preferido si está configurado, u Ollama como opción sin servicios cloud.
3. **Análisis de imágenes con Gemini:** subir una imagen PNG/JPG/WebP, pedir descripciones, lectura visual y recomendaciones.
4. **Generación de imágenes:** solicita imágenes mediante un modelo Gemini de imágenes cuando tu cuenta, región y modelo tienen acceso. El costo o límites dependen del proveedor.
5. **BAQUEANO Control Center:** conexión en lectura con web oficial y API de GitHub; explorador de directorios; lectura de archivos de contenido; previsualización `diff`; creación **confirmada** de rama y Pull Request en GitHub; lectura de vistas públicas Supabase sujetas a RLS.
6. **Módulos existentes conservados:** finanzas locales, CRM de prospectos, oportunidades, noticias RSS, música/cine (metadatos), campañas y guiones, bolsa/Bitcoin (datos de mercado), planeación de videos y audio, archivo de seguridad heurística, documentos, tareas y Engine Sensor MLP + GRU.

> **Límites reales:** Gemini no conoce toda la información automáticamente y puede equivocarse; para noticias actuales usa fuentes verificadas. Esta versión **no maneja tus cuentas bancarias, no hace trading real, no publica directamente la web, no modifica usuarios ni ejecuta un antivirus completo**. Los pagos y las operaciones de mercado son borradores o simulaciones. El motor MLP+GRU no predice automáticamente precios de criptomonedas.

## Instalación en Windows, Linux o macOS

Requiere Python 3.11 o 3.12 recomendado. Descomprime el ZIP en una carpeta local.

- Windows: `INICIAR_WINDOWS.bat`.
- Linux/macOS: `bash iniciar_linux_mac.sh`.
- Manualmente:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
python -m pip install -r requirements.txt
python -m streamlit run app.py --server.address 127.0.0.1
```

El panel se ejecuta **únicamente en tu computadora**, no en un servidor público. Normalmente la terminal muestra `http://127.0.0.1:8501`.

## Configurar Gemini

1. Crea tu clave en [Google AI Studio](https://aistudio.google.com/apikey).
2. Copia el archivo `.env.example` como `.env` en la carpeta de NeuralT.
3. Escribe **tu clave sólo en tu archivo local `.env`**, en `GEMINI_API_KEY=...`. No la pegues en conversaciones, capturas ni commits.
4. En el panel, abre **IA universal** y selecciona **Gemini (nube)**. El modelo preconfigurado `gemini-flash-latest` se puede modificar desde `.env` o el panel. La oferta de modelos y permisos cambia.
5. En **Imágenes y videos** tendrás análisis visual y generación de imágenes si el modelo de imagen está habilitado.

La aplicación envía los mensajes e imágenes que consultes a Gemini. Revisa costos, cuotas, condiciones y políticas de privacidad antes de enviar datos personales.

## Configurar BAQUEANO Control Center

Repositorio verificado: `OscarElieser/APP-BAQUEANO`. Dominio verificado por consulta pública: `https://baqueanonicaragua.com/`. La raíz del repositorio tiene `website/`, `web/`, `docs/`, `firebase.json` y configuración de Supabase. **No se modificó el repositorio durante el desarrollo de este prototipo.**

### Funciones sin secretos

- En **BAQUEANO Control Center > Estado web**: consulta estado HTTP y detección simple del texto BAQUEANO.
- En **GitHub**: ve resumen del repositorio y explora sus directorios públicos.
- En **Proponer cambio**: puedes leer archivos públicos de `website/`, `web/` o `docs/` para editar localmente el texto y revisar diferencias. Sin token no se crean Pull Requests.

### Habilitar cambios en GitHub (con confirmación)

1. Crea un **fine-grained personal access token** desde los ajustes de GitHub, restringido exclusivamente al repositorio `OscarElieser/APP-BAQUEANO`. Para este flujo necesita al menos `Contents: Read and write`, `Pull requests: Read and write` y permiso de lectura de metadatos.
2. Guarda el token en **`.env`** como `BAQUEANO_GITHUB_TOKEN=...`.
3. Ve a **Proponer cambio**, lee un archivo, edítalo, revisa el diff y escribe literalmente **CREAR PROPUESTA**. Después pulsa *Crear rama y Pull Request*.
4. NeuralT crea una rama `neuralt/revision-...` y un Pull Request. **NO altera `main` directamente**, ni desplegará producción sin una revisión y aceptación posterior en GitHub.
5. Solo se permiten archivos de contenido de `website/`, `web/` y `docs/` con extensiones `.html`, `.css`, `.js`, `.md`, `.txt`, `.svg`. Archivos secretos, workflows y configuraciones sensibles quedan excluidos.

El módulo **no da control de administración total** sobre la web: para publicar, cambiar datos privados de Ops Center y gestionar usuarios se requiere integrar endpoints y permisos administrativos reales del backend de BAQUEANO y verificar su esquema y política de acceso. Esto no debe sustituirse por guardar una clave `service_role` en el navegador.

### Datos de Supabase

- En `.env` configura `BAQUEANO_SUPABASE_URL=https://...supabase.co` y `BAQUEANO_SUPABASE_PUBLISHABLE_KEY=sb_publishable_...`.
- Esta versión consulta, si el proyecto las expone, únicamente `destinations`, `businesses`, `places`, `public_ecosystem_metrics`.
- Sólo se usa el encabezado `apikey` con una **clave publicable**. El API aplicará RLS, `GRANT` y exposición de tablas; un error HTTP 401/403/404 significa que la lectura no está habilitada o la vista no existe. Nunca uses `sb_secret_*` ni `service_role` en este archivo para esta función.

Supabase anunció cambios de exposición de nuevas tablas y claves en 2026; consulta su [documentación de API Keys](https://supabase.com/docs/guides/getting-started/api-keys) y [Data API](https://supabase.com/docs/guides/api/creating-routes).

## Seguridad y privacidad

- `.env`, tokens, bases SQLite de `local_data/`, `.venv` y cachés están excluidos del ZIP y de `.gitignore`.
- Nunca compartas tus claves/API tokens; utiliza controles de cuotas, presupuesto y revocación de tokens.
- La aplicación Streamlit es **local**, no tiene autenticación multiusuario; si quieres ejecutarla en Internet hay que instalar una autenticación robusta, proxy seguro, HTTPS, control de acceso y registro de auditoría.
- Los resultados de IA **no ejecutan comandos** ni hacen cambios automáticos en el repositorio; solamente las acciones que pulses en botones podrán producir llamadas externas.
- Auditorías y pruebas de seguridad sólo en activos propios o autorizados.

## Estado de verificación

- `14` pruebas unitarias/locales verifican cálculos existentes, validaciones, flujos de confirmación, lectura de archivos y llamada simulada a Gemini **sin red**.
- `python -m compileall -q app.py neural_core sensores_app.py` pasó.
- **Pendiente de probar con credenciales reales**: llamada externa Gemini, generación de imágenes, consulta autenticada GitHub/Supabase y creación real de PR. No se desplegó BAQUEANO ni se ejecutaron pagos.
- La interfaz Streamlit no pudo probarse visualmente en el entorno de preparación. Debe iniciarse desde la computadora de destino.

```bash
python -m pytest -q
```

## Módulos y estructura

- `app.py`: interfaz local Streamlit.
- `neural_core/assistant.py`: chat con recuperación de documentos y elección de proveedor.
- `neural_core/gemini_provider.py`: Gemini texto, imágenes y visión.
- `neural_core/baqueano.py`: estado del sitio, cliente de GitHub, PR revisables y lecturas públicas Supabase.
- `neural_core/*`: finanzas, CRM, campañas, mercado, noticias, archivos y seguridad.
- `sensores_app.py`, `motor.py`, `modelo.py`, `entrenar.py`: sensores MLP+GRU (modelo entrenado con datos de demostración, no mercados bursátiles).

**Siguiente etapa para control privado completo de BAQUEANO:** integrar autenticación del Ops Center y endpoints autorizados para reseñas, destinos, negocios y análisis de ventas, con permisos RBAC y trazabilidad. Primero se debe inspeccionar la implementación real y comprobar los roles, evitando sobreescribir lo existente.
